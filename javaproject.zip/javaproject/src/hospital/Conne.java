package hospital;

import java.sql.*;  

public class Conne{
    Connection c;
    Statement s;
    public Conne(){  
        try{  
            Class.forName("com.mysql.jdbc.Driver");  
            Connection c = DriverManager.getConnection("jdbc:mysql:///hospitalmss","root","Ananya@2003");

            
            s =c.createStatement();  
            
           
        }catch(Exception e){ 
            System.out.println(e);
        }  
    }  
}